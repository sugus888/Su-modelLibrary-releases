SU Model Library - Installation
================================

Close SketchUp first. The installer finds every SketchUp 2024 or newer and
installs (or updates) the extension in all of them.

Windows
  Install / update : double-click install.cmd
  Uninstall        : double-click uninstall.cmd
  (If Windows SmartScreen appears: More info > Run anyway)

macOS
  Install / update : double-click install.command
                     (if blocked: right-click > Open, or in Terminal:
                      bash install.command)
  Uninstall        : bash install.command --uninstall

Then start SketchUp and open:
  Extensions > SU Model Library > Open Library

If SketchUp has never been started on this computer, start and close it once
before running the installer (it creates the Plugins folder).

Manual alternative (no scripts):
  Extensions > Extension Manager > Install Extension > choose the .rbz file
