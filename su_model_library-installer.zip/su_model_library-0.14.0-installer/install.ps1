# SU Model Library installer for Windows.
# Copies the extension from the .rbz next to this script into the Plugins
# folder of every installed SketchUp 2024+ (per user, no admin rights needed).
#
#   install.cmd              install / update
#   uninstall.cmd            remove
#
# Messages are ASCII only: Windows PowerShell 5.1 misreads UTF-8 scripts without BOM.
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$ExtName = 'su_model_library'
$MinYear = 2024
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-InstalledVersion([string]$RootFile) {
    if (-not (Test-Path -LiteralPath $RootFile)) { return $null }
    $match = Select-String -LiteralPath $RootFile -Pattern "VERSION = '([^']+)'" | Select-Object -First 1
    if ($match) { return $match.Matches[0].Groups[1].Value }
    return 'unknown'
}

function Get-SketchUpTargets {
    $base = Join-Path $env:APPDATA 'SketchUp'
    Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^SketchUp (\d{4})$' -and [int]$Matches[1] -ge $MinYear } |
        Sort-Object Name
}

function Wait-SketchUpClosed {
    while (Get-Process -Name 'SketchUp' -ErrorAction SilentlyContinue) {
        Write-Host 'SketchUp is running. Please save your work and close SketchUp, then press Enter.' -ForegroundColor Yellow
        [void](Read-Host)
    }
}

function Remove-Extension([string]$Plugins) {
    Remove-Item -LiteralPath (Join-Path $Plugins "$ExtName.rb") -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $Plugins $ExtName) -Recurse -Force -ErrorAction SilentlyContinue
}

try {
    $targets = @(Get-SketchUpTargets)
    if ($targets.Count -eq 0) {
        throw "No SketchUp $MinYear or newer found in $env:APPDATA\SketchUp. Start SketchUp once, close it, then run this again."
    }

    Wait-SketchUpClosed

    if ($Uninstall) {
        foreach ($t in $targets) {
            $plugins = Join-Path (Join-Path $t.FullName 'SketchUp') 'Plugins'
            $old = Get-InstalledVersion (Join-Path $plugins "$ExtName.rb")
            if ($old) {
                Remove-Extension $plugins
                Write-Host "[$($t.Name)] removed v$old" -ForegroundColor Green
            } else {
                Write-Host "[$($t.Name)] not installed"
            }
        }
        exit 0
    }

    # Pick the highest version by file name, not the newest file date: several
    # downloads may sit in the same folder and dates do not follow versions.
    $rbz = Get-ChildItem -LiteralPath $Here -Filter "$ExtName-*.rbz" |
        Where-Object { $_.Name -match "^$ExtName-(\d+)\.(\d+)\.(\d+)\.rbz$" } |
        Sort-Object { [version]($_.Name -replace "^$ExtName-|\.rbz$", '') } -Descending |
        Select-Object -First 1
    if (-not $rbz) { throw "No $ExtName-<version>.rbz found next to this script ($Here)." }
    Write-Host "Package: $($rbz.FullName)"

    # Expand-Archive only accepts .zip, and an .rbz is a zip file.
    $work = Join-Path ([IO.Path]::GetTempPath()) ("sml-install-" + [guid]::NewGuid())
    New-Item -ItemType Directory -Path $work | Out-Null
    try {
        $zip = Join-Path $work 'package.zip'
        Copy-Item -LiteralPath $rbz.FullName -Destination $zip
        $src = Join-Path $work 'src'
        Expand-Archive -LiteralPath $zip -DestinationPath $src
        $newRoot = Join-Path $src "$ExtName.rb"
        if (-not (Test-Path -LiteralPath $newRoot) -or -not (Test-Path -LiteralPath (Join-Path $src $ExtName))) {
            throw "$($rbz.Name) is not a valid package (missing $ExtName.rb or $ExtName folder)."
        }
        $newVersion = Get-InstalledVersion $newRoot
        Write-Host "Installing SU Model Library v$newVersion" -ForegroundColor Cyan

        foreach ($t in $targets) {
            $plugins = Join-Path (Join-Path $t.FullName 'SketchUp') 'Plugins'
            New-Item -ItemType Directory -Path $plugins -Force | Out-Null
            $old = Get-InstalledVersion (Join-Path $plugins "$ExtName.rb")

            # Remove old files first so files deleted in the new version do not linger.
            Remove-Extension $plugins
            Copy-Item -LiteralPath (Join-Path $src $ExtName) -Destination $plugins -Recurse
            Copy-Item -LiteralPath $newRoot -Destination $plugins

            $label = if ($old -eq $newVersion) { "reinstalled v$newVersion" }
                     elseif ($old) { "updated v$old -> v$newVersion" }
                     else { "installed v$newVersion" }
            Write-Host "[$($t.Name)] $label" -ForegroundColor Green
        }
    } finally {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }

    Write-Host ''
    Write-Host 'Done. Start SketchUp, then open Extensions > SU Model Library > Open Library.'
    exit 0
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
