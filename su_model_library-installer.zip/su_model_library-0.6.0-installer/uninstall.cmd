@echo off
rem Double-click to remove SU Model Library from every SketchUp 2024+.
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Uninstall
set RC=%ERRORLEVEL%
echo.
pause
exit /b %RC%
