#!/bin/bash
# SU Model Library installer for macOS.
# Double-click (or run `bash install.command` in Terminal) to install/update the
# extension in every SketchUp 2024+. Run with --uninstall to remove it.
set -euo pipefail

EXT=su_model_library
MIN_YEAR=2024
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE="$HOME/Library/Application Support"
MODE=install
[[ "${1:-}" == "--uninstall" ]] && MODE=uninstall

fail() { echo "ERROR: $*" >&2; exit 1; }

installed_version() {
  [[ -f "$1" ]] || return 0
  sed -n "s/.*VERSION = '\([^']*\)'.*/\1/p" "$1" | head -n 1
}

targets=()
for dir in "$BASE"/SketchUp\ 20*; do
  [[ -d "$dir" ]] || continue
  year="${dir##*SketchUp }"
  [[ "$year" =~ ^[0-9]{4}$ ]] && (( year >= MIN_YEAR )) && targets+=("$dir")
done
(( ${#targets[@]} > 0 )) || fail "No SketchUp $MIN_YEAR or newer found in $BASE. Start SketchUp once, quit it, then run this again."

while pgrep -x SketchUp >/dev/null 2>&1; do
  read -r -p "SketchUp is running. Save your work, quit SketchUp (Cmd+Q), then press Enter. "
done

if [[ "$MODE" == uninstall ]]; then
  for dir in "${targets[@]}"; do
    plugins="$dir/SketchUp/Plugins"
    old="$(installed_version "$plugins/$EXT.rb")"
    if [[ -n "$old" ]]; then
      rm -rf "${plugins:?}/$EXT" "${plugins:?}/$EXT.rb"
      echo "[$(basename "$dir")] removed v$old"
    else
      echo "[$(basename "$dir")] not installed"
    fi
  done
  exit 0
fi

# Highest version by file name, not the newest file date: several downloads
# may sit in the same folder and dates do not follow versions.
rbz=""
best=""
for candidate in "$HERE"/$EXT-*.rbz; do
  name="$(basename "$candidate")"
  [[ "$name" =~ ^$EXT-([0-9]+)\.([0-9]+)\.([0-9]+)\.rbz$ ]] || continue
  key="$(printf '%05d%05d%05d' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}")"
  if [[ -z "$best" || "$key" > "$best" ]]; then best="$key"; rbz="$candidate"; fi
done
[[ -n "$rbz" ]] || fail "No $EXT-<version>.rbz found next to this script ($HERE)."
echo "Package: $rbz"

work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
unzip -q "$rbz" -d "$work/src"
[[ -f "$work/src/$EXT.rb" && -d "$work/src/$EXT" ]] || fail "$(basename "$rbz") is not a valid package."
new="$(installed_version "$work/src/$EXT.rb")"
echo "Installing SU Model Library v$new"

for dir in "${targets[@]}"; do
  plugins="$dir/SketchUp/Plugins"
  mkdir -p "$plugins"
  old="$(installed_version "$plugins/$EXT.rb")"
  # Remove old files first so files deleted in the new version do not linger.
  rm -rf "${plugins:?}/$EXT" "${plugins:?}/$EXT.rb"
  cp -R "$work/src/$EXT" "$work/src/$EXT.rb" "$plugins/"
  # Files from a browser download carry a quarantine flag; drop it for the plugin files.
  xattr -dr com.apple.quarantine "$plugins/$EXT" "$plugins/$EXT.rb" 2>/dev/null || true
  if [[ "$old" == "$new" ]]; then
    echo "[$(basename "$dir")] reinstalled v$new"
  elif [[ -n "$old" ]]; then
    echo "[$(basename "$dir")] updated v$old -> v$new"
  else
    echo "[$(basename "$dir")] installed v$new"
  fi
done

echo
echo "Done. Start SketchUp, then open Extensions > SU Model Library > Open Library."
